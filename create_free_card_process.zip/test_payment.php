<?php
// Quick test script for payment.php
$_SESSION['user'] = ['id' => 1, 'fullname' => 'Test User'];

require 'payment.php';
