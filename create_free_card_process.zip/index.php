<?php
// Azure Web App Entry Point
// Redirect to login.php as main entry
header('Location: login.php');
exit;
